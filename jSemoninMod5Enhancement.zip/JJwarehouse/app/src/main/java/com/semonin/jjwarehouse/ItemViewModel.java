/** This class is a place holder and serves no purpose currently, I had a different intended design that would need this class but currently there is no function to it
*/
package com.semonin.jjwarehouse;

import androidx.lifecycle.ViewModel;

public class ItemViewModel extends ViewModel {
    // Add LiveData and methods to interact with the database
}
